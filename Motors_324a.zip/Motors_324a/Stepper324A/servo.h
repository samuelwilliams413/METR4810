
void move_servo(uint16_t angle);
void servo_init(void);
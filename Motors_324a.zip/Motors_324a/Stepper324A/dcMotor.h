#include <avr/io.h>

void clockwiseB(uint16_t pwm);
void counterclockwiseB(uint16_t pwm);
void motor_initB();